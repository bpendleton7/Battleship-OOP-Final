package com.example.battleship;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Transition extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transition);
    }
}
