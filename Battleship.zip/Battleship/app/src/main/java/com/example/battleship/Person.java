package com.example.battleship;

public class Person extends Player {

    public Person() {
    }

    public Person(String name, Board board) {
        super(name, board);
    }

//    @Override
//    int userPlacePiece() {
//        //battleshipView.getUserPlacement()   ?????
//        return 0;
//    }
}
