package com.example.battleship;

    public enum Ship {
        Carrier,
        Destroyer,
        Battleship,
        Cruiser,
        Submarine
    }

